# -*- coding: utf-8 -*-
import json
from urllib.parse import unquote
from caches.personal_lists_cache import personal_lists_cache, get_timestamp
from modules.kodi_utils import select_dialog, kodi_dialog, notification, kodi_refresh, external, path_check, get_icon, kodi_refresh, confirm_dialog
from modules.utils import sort_for_article
# from modules.kodi_utils import logger

list_icon = get_icon('lists')
media_check = {'movie': 'movie', 'tvshow': 'show'}
sort_order_dict = {'0': 'Title', '1': 'Date Added', '2': 'Release Date', '': 'Title', 'None': 'Title'}

def make_new_personal_list(list_name, list_type, sort_order):
	return personal_lists_cache.make_list(list_name, list_type, sort_order)

def get_all_personal_lists(list_type=None):
	return personal_lists_cache.get_lists(list_type)

def delete_personal_list(params):
	list_name, list_type = params.get('list_name', ''), params.get('list_type', '')
	if not confirm_dialog(heading='Personal Lists', text='Delete [B]%s[/B] Personal List?' % list_name): return
	if personal_lists_cache.delete_list(list_name, list_type): return kodi_refresh()
	notification('Error Deleting List', 3000)

def delete_personal_list_contents(params):
	list_name, list_type = params.get('list_name', ''), params.get('list_type', '')
	if not confirm_dialog(heading='Personal Lists', text='Delete all the contents of [B]%s[/B] Personal List?' % list_name): return
	if personal_lists_cache.delete_list_contents(list_name, list_type): return kodi_refresh()
	notification('Error Deleting List Contents', 3000)

def get_personal_list(params, list_type):
	list_name, sort_order = params['list_name'], params['sort_order']
	contents = personal_lists_cache.get_list(list_name, list_type)
	try:
		if sort_order in ('', '0', 'None'): contents = sort_for_article(contents, 'title')
		elif sort_order == '1': contents.sort(key=lambda k: k['date_added'], reverse=True)
		else: contents.sort(key=lambda k: (k['release_date'] is None, k['release_date']), reverse=True)
	except: pass
	return contents

# def add_remove_personal_list(params):
# 	icon = params.get('icon', None) or list_icon
# 	list_type = params['list_type']
# 	all_lists = get_all_personal_lists(list_type)
# 	choices = []
# 	if not all_lists: action = 'add_new'
# 	else:
# 		choices = [('Add To Personal List...', 'add'), ('Remove From Personal List...', 'remove'), ('Add To [B]NEW[/B] Personal List...', 'add_new')]
# 		list_items = [{'line1': item[0], 'icon': icon} for item in choices]
# 		kwargs = {'items': json.dumps(list_items), 'heading': 'Personal Lists Manager'}
# 		action = select_dialog([i[1] for i in choices], **kwargs)
# 		if action == None: return
# 	if action == 'add_new':
# 		list_name, list_type, sort_order = make_new_personal_list({'list_type': list_type, 'refresh': 'false'})
# 		if not list_name: return notification('Error Creating List', 3000)
# 		action = 'add'
# 	else:
# 		choices = [('%s [I](x%02d)[/I]' % (i['name'], i['total']), i['name']) for i in all_lists]
# 		list_items = [{'line1': i[0]} for i in choices]
# 		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
# 		list_name = select_dialog([i[1] for i in choices], **kwargs)
# 		if list_name == None: return
# 	if action == 'add': new_contents = {'media_id': params['tmdb_id'], 'title': params['title'], 'release_date': params['premiered'], 'date_added': params['current_time']}
# 	else: new_contents = params['tmdb_id']
# 	result = personal_lists_cache.add_remove_list_item(action, new_contents, list_name, list_type)
# 	notification(result, 3000)
# 	if action == 'remove' and any([path_check(list_name) or external()]): kodi_refresh()

def make_new_personal_list(params):
	def cancel_or_retry(dialog):
		if confirm_dialog(heading='Personal Lists', text='Re-enter [B]%s[/B] Value or Cancel Making List?' % dialog, ok_label='Re-enter', default_control=10):
			return make_new_personal_list(params)
		return None, None, None
	list_name, list_type, sort_order = params.get('list_name', ''), params.get('list_type', ''), params.get('sort_order', '')
	if not list_name:
		list_name = personal_list_name(list_name)
		if list_name == None: return cancel_or_retry('List Name')
		params['list_name'] = list_name
	if not list_type:
		list_type = personal_list_type()
		if list_type == None: return cancel_or_retry('List Type')
		params['list_type'] = list_type
	if not sort_order:
		sort_order = personal_sort_order()
		if sort_order == None: return cancel_or_retry('Sort Order')
		params['sort_order'] = sort_order
	success = personal_lists_cache.make_list(list_name, list_type, sort_order)
	if not success:
		notification('Error Creating List', 3000)
		return None, None, None
	if params.get('refresh', 'true') == 'true' and any([path_check('navigator.personal_lists') or external()]): kodi_refresh()
	return list_name, list_type, sort_order

def adjust_personal_list_properties(params):
	original_list_name, original_list_type, original_sort_order = params.get('original_list_name', ''), params.get('original_list_type', ''), params.get('original_sort_order', '')
	list_name, list_type, list_total, sort_order = params.get('list_name', ''), params.get('list_type', ''), params.get('list_total', '0'), params.get('sort_order', '')
	current_name, current_type, current_sort_order = list_name or original_list_name, list_type or original_list_type, sort_order or original_sort_order
	choices = [('List Name', 'Currently [B]%s[/B]' % (current_name), 'list_name')]
	if int(list_total) == 0: choices.append(('List Type', 'Currently [B]%s[/B]' % (current_type), 'list_type'))
	choices.append(('List Sort Order', 'Currently [B]%s[/B]' % sort_order_dict[current_sort_order], 'sort_order'))
	list_items = [{'line1': item[0], 'line2': item[1] or item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Personal List Properties', 'multi_line': 'true', 'narrow_window': 'true'}
	action = select_dialog([i[2] for i in choices], **kwargs)
	if action == None: return kodi_refresh() if params.get('refresh', 'false') == 'true' else None
	if action == 'list_name':
		list_name = personal_list_name(current_name)
		if list_name == None: return adjust_personal_list_properties(params)
		current_name = list_name
		params.update({'list_name': current_name, 'refresh': 'true'})
	elif action == 'list_type':
		list_type = personal_list_type()
		if list_type == None: return adjust_personal_list_properties(params)
		current_type = list_type
		params.update({'list_type': current_type, 'refresh': 'true'})
	elif action == 'sort_order':
		sort_order = personal_sort_order()
		if sort_order == None: return adjust_personal_list_properties(params)
		current_sort_order = sort_order
		params.update({'sort_order': current_sort_order, 'refresh': 'true'})
	personal_lists_cache.update_list_details(current_name, current_type, current_sort_order, original_list_name, original_list_type)
	return adjust_personal_list_properties(params)

def import_trakt_list(params):
	from apis.trakt_api import get_trakt_list_selection, trakt_fetch_collection_watchlist, get_trakt_list_contents
	list_name, list_type = params.get('list_name', ''), params.get('list_type', '')
	chosen_list = get_trakt_list_selection(include_liked=True)
	if chosen_list == None: return
	trakt_list_type, trakt_list_name = chosen_list.get('list_type'), chosen_list.get('name')
	if trakt_list_type in ('my_lists', 'liked_lists'):
		text = 'This Personal List is for [B]%s[/B] content. Only media matching this type from [B]%s[/B] will be imported. Continue?' % (list_type.upper(), trakt_list_name)
		if not confirm_dialog(heading='Personal Lists', text=text): return
	new_contents = []
	new_contents_append = new_contents.append
	current_time = get_timestamp()	
	if trakt_list_type in ('collection', 'watchlist'):
		result = trakt_fetch_collection_watchlist(trakt_list_type, list_type)
		try: result.sort(key=lambda k: (k['collected_at']))
		except: pass
	else:
		result = get_trakt_list_contents(trakt_list_type, chosen_list.get('user'), chosen_list.get('slug'), trakt_list_type == 'my_lists')
		try: result.sort(key=lambda k: (k['order']))
		except: pass
	for count, item in enumerate(result):
		try:
			media_id = item['media_ids']['tmdb']
			if media_id in (None, 'None', ''): continue
			if trakt_list_type in ('my_lists', 'liked_lists') and media_check[list_type] != item['media_type']: continue
			title = item['title']
			try: release_date = item['released'].split('T')[0]
			except: release_date = item['released']
			date_added = current_time + count
			new_contents_append({'media_id': str(media_id), 'title': title, 'release_date': release_date, 'date_added': str(date_added)})
		except: continue
	result = personal_lists_cache.add_many_list_items(new_contents, list_name, list_type)
	notification(result, 3000)
	if any([path_check('navigator.personal_lists') or external()]): kodi_refresh()

def personal_list_name(current_name=''):
	list_name = kodi_dialog().input('Please Choose a Name for the New List', defaultt=current_name)
	if not list_name: return None
	list_name = unquote(list_name)
	return list_name

def personal_list_type():
	choices = [('Movie List', 'movie'), ('TV Show List', 'tvshow')]
	list_items = [{'line1': i[0]} for i in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'List Type', 'narrow_window': 'true'}
	list_type = select_dialog([i[1] for i in choices], **kwargs)
	if list_type == None: return None
	return list_type

def personal_sort_order():
	choices = [('Title', '0'), ('Date Added', '1'), ('Release Date', '2')]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'List Sort Order', 'narrow_window': 'true'}
	sort_order = select_dialog([i[1] for i in choices], **kwargs)
	if sort_order == None: return None
	return sort_order
