# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, get_timestamp
from modules.kodi_utils import logger

MAKE_LIST = 'INSERT OR REPLACE INTO personal_lists VALUES (?, ?, ?, ?, ?, ?)'
SELECT_ALL_LISTS = 'SELECT name, type, total, sort_order FROM personal_lists'
SELECT_ALL_TYPE_LISTS = 'SELECT name, type, total, sort_order FROM personal_lists WHERE type=?'
SELECT_LIST = 'SELECT contents FROM personal_lists WHERE name=? AND type=?'
UPDATE_LIST_ADD = 'UPDATE personal_lists SET contents=?, total=total+1 WHERE name=? AND type=?'
UPDATE_LIST_ADD_MANY = 'UPDATE personal_lists SET contents=?, total=? WHERE name=? AND type=?'
UPDATE_LIST_REMOVE = 'UPDATE personal_lists SET contents=?, total=total-1 WHERE name=? AND type=?'
UPDATE_LIST_DETAILS = 'UPDATE personal_lists SET name=?, type=?, sort_order=? WHERE name=? AND type=?'
UPDATE_LIST_CONTENTS = 'UPDATE personal_lists SET contents=?, total=? WHERE name=? AND type=?'
DELETE_LIST = 'DELETE FROM personal_lists WHERE name=? AND type=?'

class PersonalListsCache:
	def make_list(self, list_name, list_type, sort_order):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute(MAKE_LIST, (list_name, list_type, repr([]), 0, get_timestamp(), sort_order))
			return True
		except: return False

	def delete_list(self, list_name, list_type):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute(DELETE_LIST, (list_name, list_type))
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_list_contents(self, list_name, list_type):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute(UPDATE_LIST_CONTENTS, (repr([]), '0', list_name, list_type))
			return True
		except: return False

	def update_list_details(self, list_name, list_type, sort_order, original_name, original_type):
		try:
			dbcon = connect_database('personal_lists_db')
			dbcon.execute(UPDATE_LIST_DETAILS, (list_name, list_type, sort_order, original_name, original_type))
			return True
		except: return False

	def get_lists(self, list_type=None):
		try:
			dbcon = connect_database('personal_lists_db')
			if list_type: all_lists = dbcon.execute(SELECT_ALL_TYPE_LISTS, (list_type,)).fetchall()
			else: all_lists = dbcon.execute(SELECT_ALL_LISTS).fetchall()
			return [{'name': str(i[0]), 'type': str(i[1]), 'total': i[2], 'sort_order': i[3]} for i in all_lists]
		except: return []

	def get_list(self, list_name, list_type, dbcon=None):
		try:
			if not dbcon: dbcon = connect_database('personal_lists_db')
			return eval(dbcon.execute(SELECT_LIST, (list_name, list_type)).fetchone()[0])
		except: return []

	def add_remove_list_item(self, action, new_contents, list_name, list_type):
		try:
			dbcon = connect_database('personal_lists_db')
			contents = self.get_list(list_name, list_type, dbcon)
			if action == 'add':
				if [str(i['media_id']) for i in contents if str(new_contents['media_id']) == str(i['media_id'])]: return 'Item Already in [B]%s[/B]' % list_name
				command = UPDATE_LIST_ADD
				contents.append(new_contents)
			else:
				if not [str(i['media_id']) for i in contents if str(new_contents) == str(i['media_id'])]: return 'Item Not in [B]%s[/B]' % list_name
				command = UPDATE_LIST_REMOVE
				contents = [i for i in contents if not str(i['media_id']) == str(new_contents)]
			dbcon.execute(command, (repr(contents), list_name, list_type))
			return 'Success'
		except: return 'Error'

	def add_many_list_items(self, new_contents, list_name, list_type):
		try:
			dbcon = connect_database('personal_lists_db')
			contents = self.get_list(list_name, list_type, dbcon)
			compare_ids = [str(i['media_id']) for i in contents]
			new_contents = [i for i in new_contents if str(i['media_id']) not in compare_ids]
			contents.extend(new_contents)
			dbcon.execute(UPDATE_LIST_ADD_MANY, (repr(contents), len(contents), list_name, list_type))
			return 'Success'
		except: return 'Error'

personal_lists_cache = PersonalListsCache()
