# -*- coding: utf-8 -*-
import sys
from modules.router import routing
# from modules.kodi_utils import logger

if routing(sys): sys.exit(1)