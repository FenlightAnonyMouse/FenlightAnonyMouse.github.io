# -*- coding: utf-8 -*-
if __name__ == '__main__':
	import sys
	from modules.router import Router
	with Router() as r: r.routing(sys)

