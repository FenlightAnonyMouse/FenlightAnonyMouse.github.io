# -*- coding: utf-8 -*-
import sys
from modules.router import Router

with Router() as r: r.routing(sys)

