# -*- coding: utf-8 -*-
# if __name__ == '__main__':
# 	import sys
# 	from modules.router import Router
# 	with Router() as r: r.routing(sys)


if __name__ == '__main__':
	import sys
	from urllib.parse import parse_qsl
	from modules.router import Router
	with Router() as r:
		try: params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
		except: pass
		else: r.routing(params)

